"""
Codebase for TopoDiff, a diffusion-model-based architecture for topology optimization.
The code started out as a PyTorch port of Dhariwal & Nichol's diffusion model:
https://github.com/openai/guided-diffusion
"""